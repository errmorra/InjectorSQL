"""
InjectorSQL — DAST SQL Injection Vulnerability Scanner
"""

__version__ = "1.0.0"
__author__ = "InjectorSQL Contributors"
__license__ = "MIT"

from .crawler import Spider, EntryPoint
from .payloads import PayloadLibrary, Payload, WafBypass
from .engine import InjectionEngine
from .detector import Analyst, Finding
from .reporter import Reporter
from .utils import logger, banner, validate_target

__all__ = [
    "Spider",
    "EntryPoint",
    "PayloadLibrary",
    "Payload",
    "WafBypass",
    "InjectionEngine",
    "Analyst",
    "Finding",
    "Reporter",
    "logger",
    "banner",
    "validate_target",
]
