"""
InjectorSQL — Utilities
Shared helpers: logging, banner, URL validation, diff scoring.
"""

import logging
import re
import sys
from difflib import SequenceMatcher
from urllib.parse import urlparse

# ── Logging ──────────────────────────────────────────────────────────────────

LOG_FORMAT = "%(asctime)s  %(levelname)-8s  %(message)s"
DATE_FORMAT = "%H:%M:%S"

logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format=LOG_FORMAT,
    datefmt=DATE_FORMAT,
)
logger = logging.getLogger("injector_sql")


def set_verbose(verbose: bool):
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)


# ── Banner ────────────────────────────────────────────────────────────────────

BANNER = r"""
  ___       _           _             ____   ___  _     
 |_ _|_ __ (_) ___  ___| |_ ___  _ _/ ___| / _ \| |    
  | || '_ \| |/ _ \/ __| __/ _ \| '_\___ \| | | | |    
  | || | | | |  __/ (__| || (_) | |  ___) | |_| | |___ 
 |___|_| |_| |\___|\___|\__\___/|_| |____/ \__\_\_____|
          |__/                                           
              DAST SQL Injection Scanner  v1.0.0
   ⚠  For authorized testing only — DVWA / Juice Shop ⚠
"""


def banner():
    print(BANNER)
    print("=" * 57)
    print()


# ── Target Validation ─────────────────────────────────────────────────────────

PRIVATE_RANGES = [
    r"^10\.",
    r"^192\.168\.",
    r"^172\.(1[6-9]|2[0-9]|3[01])\.",
    r"^127\.",
    r"^::1$",
    r"^localhost$",
]


def validate_target(url: str) -> tuple[bool, str]:
    """
    Basic sanity checks.  Deliberately permissive so lab environments
    (localhost, 192.168.x.x, Docker networks) all pass.
    """
    try:
        parsed = urlparse(url)
    except Exception as e:
        return False, f"Invalid URL: {e}"

    if parsed.scheme not in ("http", "https"):
        return False, f"Scheme must be http or https, got: {parsed.scheme!r}"

    hostname = parsed.hostname or ""
    if not hostname:
        return False, "No hostname found in URL."

    return True, "OK"


# ── Fuzzy Diff ────────────────────────────────────────────────────────────────

def similarity_ratio(a: str, b: str) -> float:
    """Return a similarity ratio in [0, 1] between two HTML strings."""
    return SequenceMatcher(None, a, b).ratio()


def content_changed(baseline: str, injected: str, threshold: float = 0.05) -> bool:
    """
    Return True if the injected response differs significantly from baseline.
    threshold: fraction of content that must differ to flag.
    """
    ratio = similarity_ratio(baseline, injected)
    return ratio < (1.0 - threshold)


# ── Misc Helpers ──────────────────────────────────────────────────────────────

def truncate(text: str, max_len: int = 120) -> str:
    return text if len(text) <= max_len else text[:max_len] + "…"


def clean_html(html: str) -> str:
    """Strip tags for lightweight text comparison."""
    return re.sub(r"<[^>]+>", "", html)


def normalize_url(url: str) -> str:
    """Remove trailing slash and fragments."""
    return url.split("#")[0].rstrip("/")


SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def sort_findings(findings: list) -> list:
    return sorted(findings, key=lambda f: SEVERITY_ORDER.get(f.get("severity", "Info"), 99))
