#!/usr/bin/env bash
# ────────────────────────────────────────────────────────────
#  InjectorSQL — Example Scan Recipes
#  Run these ONLY against lab environments you own/operate.
# ────────────────────────────────────────────────────────────

# Prerequisites: DVWA or Juice Shop running locally via Docker.
# See docker-compose.yml in this repo for a quick lab setup.

# ── 1. Quick scan of DVWA (low security, all payload types) ──
injector-sql \
  -u "http://localhost:8080" \
  --cookie "PHPSESSID=YOUR_SESSION_ID; security=low" \
  --depth 3 \
  --threads 10 \
  --output html \
  --report-file reports/dvwa_full.html

# ── 2. Error-based only, verbose ─────────────────────────────
injector-sql \
  -u "http://localhost:8080/vulnerabilities/sqli/?id=1&Submit=Submit" \
  --cookie "PHPSESSID=YOUR_SESSION_ID; security=low" \
  --error-based \
  --verbose

# ── 3. Time-based scan with custom delay threshold ───────────
injector-sql \
  -u "http://localhost:8080" \
  --cookie "PHPSESSID=YOUR_SESSION_ID; security=low" \
  --time-based \
  --delay-threshold 4.0 \
  --threads 3

# ── 4. WAF bypass mode ────────────────────────────────────────
injector-sql \
  -u "http://localhost:8080" \
  --cookie "PHPSESSID=YOUR_SESSION_ID; security=medium" \
  --waf-bypass \
  --boolean-based \
  --output json \
  --report-file reports/dvwa_waf_test.json

# ── 5. OWASP Juice Shop (port 3000) ──────────────────────────
injector-sql \
  -u "http://localhost:3000" \
  --depth 2 \
  --threads 8 \
  --timeout 15 \
  --output html \
  --report-file reports/juiceshop_scan.html

# ── 6. Custom payloads + proxy through Burp Suite ────────────
injector-sql \
  -u "http://localhost:8080" \
  --cookie "PHPSESSID=YOUR_SESSION_ID; security=low" \
  --custom-payloads examples/custom_payloads.txt \
  --proxy http://127.0.0.1:8080 \
  --verify-ssl

# ── 7. Forms only, JSON output, CI/CD pipeline mode ──────────
injector-sql \
  -u "http://localhost:8080" \
  --forms-only \
  --quiet \
  --output json \
  --report-file reports/ci_scan.json
# Exit code 1 = findings found; use in pipeline:
# if ! injector-sql ...; then echo "SQLi found — blocking merge"; exit 1; fi
